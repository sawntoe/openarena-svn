OpenArena Soundtrack Source Files
By Jute Gyte


These are the sounds used to create the music I contributed to OpenArena.  The content is as follows:

Kick, Snare, Hat 1, Hat 2 - the minimal drum palette.  Derived mostly from modifying a recording of me playing the drums (Hat 1 is synthetic).
Distorted Guitar - the distorted guitar riffs from OA01.
Bass - the bass guitar riffs from OA01.
Clean Guitar - the clean guitar riffs from OA01.

My working process in creating all pieces after OA01 was simply to use OA01's constituent elements as sample sources, creating new riffs through chopping, re-pitching, reversing, and otherwise manipulating the content included in this file.

All contents licensed under the GPL.